"""
api/schemas.py
--------------
Pydantic v2 models for all API request and response payloads.

``IngestRequest`` mirrors ``cli.features.WindowFeatures`` exactly —
field names must match so the CLI's ``.to_dict()`` serialises directly
into a valid request body without any transformation.
"""

from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field, field_validator


# ── Classification labels ──────────────────────────────────────────────────────

Label = Literal["normal", "suspicious", "critical", "unknown", "pending"]


# ── POST /ingest ──────────────────────────────────────────────────────────────

class IngestRequest(BaseModel):
    """
    One window's feature vector, as sent by the CLI.

    The 16 statistical features are validated here so the API rejects
    malformed payloads before they enter the Kafka topic.
    """

    # Window metadata
    window_start: datetime
    window_end:   datetime
    agent_id:     str = Field(..., min_length=1, max_length=128)

    # ── Volume ────────────────────────────────────────────────────────────────
    query_count:         int   = Field(0, ge=0)
    unique_domain_count: int   = Field(0, ge=0)
    unique_ratio:        float = Field(0.0, ge=0.0, le=1.0)

    # ── Entropy ───────────────────────────────────────────────────────────────
    domain_entropy:            float = Field(0.0, ge=0.0)
    mean_per_domain_entropy:   float = Field(0.0, ge=0.0)
    high_entropy_domain_ratio: float = Field(0.0, ge=0.0, le=1.0)

    # ── Length ────────────────────────────────────────────────────────────────
    mean_qname_length: float = Field(0.0, ge=0.0)
    std_qname_length:  float = Field(0.0, ge=0.0)
    max_qname_length:  float = Field(0.0, ge=0.0)

    # ── TLD ───────────────────────────────────────────────────────────────────
    tld_diversity:        int   = Field(0, ge=0)
    suspicious_tld_ratio: float = Field(0.0, ge=0.0, le=1.0)

    # ── Character ─────────────────────────────────────────────────────────────
    mean_digit_ratio: float = Field(0.0, ge=0.0, le=1.0)
    mean_vowel_ratio: float = Field(0.0, ge=0.0, le=1.0)

    # ── Timing ────────────────────────────────────────────────────────────────
    inter_query_std: float = Field(0.0, ge=0.0)

    @field_validator("window_end")
    @classmethod
    def end_after_start(cls, v: datetime, info) -> datetime:
        start = info.data.get("window_start")
        if start and v <= start:
            raise ValueError("window_end must be after window_start")
        return v

    def to_feature_vector(self) -> list[float]:
        """Ordered list matching the training data column order."""
        return [
            float(self.query_count),
            float(self.unique_domain_count),
            self.unique_ratio,
            self.domain_entropy,
            self.mean_per_domain_entropy,
            self.high_entropy_domain_ratio,
            self.mean_qname_length,
            self.std_qname_length,
            self.max_qname_length,
            float(self.tld_diversity),
            self.suspicious_tld_ratio,
            self.mean_digit_ratio,
            self.mean_vowel_ratio,
            self.inter_query_std,
        ]


class IngestResponse(BaseModel):
    """Returned immediately to the CLI after accepting a window."""
    window_id:    str
    status:       str = "queued"   # "queued" or "error"


# ── GET /result/{window_id} ───────────────────────────────────────────────────

class ResultResponse(BaseModel):
    """Current classification state for a window."""
    window_id:  str
    label:      Label
    confidence: float = Field(0.0, ge=0.0, le=1.0)


# ── GET /health ───────────────────────────────────────────────────────────────

class HealthResponse(BaseModel):
    status:         str   # "ok" | "degraded"
    kafka:          str   # "ok" | "unreachable"
    redis:          str   # "ok" | "unreachable"
    uptime_seconds: float
