"""
cli/ui.py
---------
Rich-powered live terminal dashboard.

Displays one row per completed time window.  Each row shows:
  - Window timestamp
  - Query count for that second
  - Unique domain count
  - Domain entropy
  - Classification label  (color-coded)
  - Confidence score

The dashboard also shows a statistics header with uptime, total windows,
current rate, and per-label counts.

Thread safety: all writes to the internal store go through a ``threading.Lock``.
The Rich ``Live`` renderer reads the store from its own refresh thread.
"""

from __future__ import annotations

import logging
import threading
import time
from collections import deque
from dataclasses import dataclass
from datetime import datetime

from rich import box
from rich.console import Console
from rich.layout import Layout
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from cli.features import WindowFeatures
from shared.config import cli as cli_cfg

logger = logging.getLogger(__name__)


# ── Display constants ─────────────────────────────────────────────────────────

_LABEL_STYLE: dict[str, tuple[str, str]] = {
    # label → (rich markup, plain colour for domain cell)
    "normal":     ("[green]✅ normal[/green]",      "green"),
    "suspicious": ("[yellow]⚠  suspicious[/yellow]", "yellow"),
    "critical":   ("[red]❌ critical[/red]",          "red"),
    "unknown":    ("[cyan]❓ unknown[/cyan]",          "cyan"),
    "pending":    ("[dim]⏳ pending…[/dim]",          "dim"),
}


# ── Window row model ──────────────────────────────────────────────────────────

@dataclass
class WindowRow:
    """Everything the UI needs to render one window row."""
    window_id:   str
    window_time: datetime      # window_end timestamp
    query_count: int
    unique_count: int
    domain_entropy: float
    label:       str = "pending"
    confidence:  float = 0.0


# ── Dashboard ─────────────────────────────────────────────────────────────────

class Dashboard:
    """
    Live-updating Rich dashboard.

    Parameters
    ----------
    sniffer_ref
        Reference to the ``DNSSniffer`` instance — used for packet count.
    agent_id : str
        Shown in the header.
    api_url : str
        Shown in the header.
    refresh_s : float
        How often the panel redraws.
    """

    def __init__(
        self,
        sniffer_ref,
        agent_id:  str,
        api_url:   str,
        refresh_s: float = cli_cfg.ui_refresh_s,
    ) -> None:
        self._sniffer   = sniffer_ref
        self._agent_id  = agent_id
        self._api_url   = api_url
        self._refresh_s = refresh_s

        self._console   = Console()
        self._start     = datetime.now()
        self._running   = False

        self._lock = threading.Lock()
        # Ordered list — newest last
        self._rows: deque[WindowRow] = deque(maxlen=cli_cfg.max_ui_rows * 2)
        # Map window_id → WindowRow for fast result updates
        self._index: dict[str, WindowRow] = {}

    # ── public API ────────────────────────────────────────────────────────────

    def add_window(self, features: WindowFeatures, window_id: str) -> None:
        """Register a newly sent window as 'pending'."""
        row = WindowRow(
            window_id=window_id,
            window_time=features.window_end,
            query_count=features.query_count,
            unique_count=features.unique_domain_count,
            domain_entropy=features.domain_entropy,
            label="pending",
        )
        with self._lock:
            self._rows.append(row)
            self._index[window_id] = row

    def update_result(self, window_id: str, label: str, confidence: float) -> None:
        """Called by WindowSender when a classification result arrives."""
        with self._lock:
            row = self._index.get(window_id)
            if row:
                row.label      = label
                row.confidence = confidence

    def start(self) -> None:
        self._running = True
        thread = threading.Thread(target=self._live_loop, daemon=True, name="ui")
        thread.start()
        logger.info("Dashboard started.")

    def stop(self) -> None:
        self._running = False

    def print_summary(self) -> None:
        with self._lock:
            rows = list(self._rows)
        total      = len(rows)
        normal     = sum(1 for r in rows if r.label == "normal")
        suspicious = sum(1 for r in rows if r.label == "suspicious")
        critical   = sum(1 for r in rows if r.label == "critical")
        self._console.print()
        self._console.rule("[bold red]DNS Monitor Stopped[/bold red]")
        self._console.print(
            f"[bold]Session summary[/bold]  "
            f"[cyan]Windows: {total}[/cyan]  "
            f"[green]Normal: {normal}[/green]  "
            f"[yellow]Suspicious: {suspicious}[/yellow]  "
            f"[red]Critical: {critical}[/red]  "
            f"Uptime: {self._uptime()}"
        )
        self._console.print()

    # ── rendering ─────────────────────────────────────────────────────────────

    def _uptime(self) -> str:
        d = datetime.now() - self._start
        h, r = divmod(int(d.total_seconds()), 3600)
        m, s = divmod(r, 60)
        return f"{h:02d}:{m:02d}:{s:02d}"

    def _counts(self) -> dict[str, int]:
        with self._lock:
            rows = list(self._rows)
        return {
            "total":      len(rows),
            "normal":     sum(1 for r in rows if r.label == "normal"),
            "suspicious": sum(1 for r in rows if r.label == "suspicious"),
            "critical":   sum(1 for r in rows if r.label == "critical"),
            "pending":    sum(1 for r in rows if r.label == "pending"),
        }

    def _build_header(self) -> Panel:
        pkts   = getattr(self._sniffer, "packet_count", 0)
        counts = self._counts()
        lines  = [
            Text.assemble(
                ("  🛡  DNS MONITOR v3  ", "bold white"),
                ("│  WINDOW-BASED PIPELINE  │  ", "dim"),
                ("● RUNNING", "bold green"),
            ),
            Text.assemble(
                ("  Agent: ", "dim"),   (self._agent_id, "cyan"),
                ("   API: ", "dim"),    (self._api_url,  "dim cyan"),
                ("   Uptime: ", "dim"), (self._uptime(), "cyan"),
                ("   Packets: ", "dim"),(str(pkts),      "cyan"),
            ),
            Text.assemble(
                ("  Windows: ", "dim"),      (str(counts["total"]),      "cyan"),
                ("   ✅ Normal: ", "dim"),   (str(counts["normal"]),     "green"),
                ("   ⚠  Suspicious: ", "dim"),(str(counts["suspicious"]),"yellow"),
                ("   ❌ Critical: ", "dim"),  (str(counts["critical"]),  "red"),
                ("   ⏳ Pending: ", "dim"),   (str(counts["pending"]),   "dim"),
            ),
        ]
        return Panel(Text("\n").join(lines), border_style="bright_blue", padding=(0, 1))

    def _build_table(self) -> Table:
        tbl = Table(
            box=box.SIMPLE_HEAD,
            show_header=True,
            header_style="bold bright_blue",
            expand=True,
            show_edge=False,
            padding=(0, 1),
        )
        tbl.add_column("Window",    style="dim",     width=10, no_wrap=True)
        tbl.add_column("Queries",   justify="right", width=8)
        tbl.add_column("Unique",    justify="right", width=8)
        tbl.add_column("Entropy",   justify="right", width=9)
        tbl.add_column("Label",     width=18, no_wrap=True)
        tbl.add_column("Conf",      justify="right", width=7)

        with self._lock:
            rows = list(self._rows)[-cli_cfg.max_ui_rows:]

        for row in rows:
            markup, color = _LABEL_STYLE.get(row.label, ("?", "white"))
            tbl.add_row(
                row.window_time.strftime("%H:%M:%S"),
                str(row.query_count),
                str(row.unique_count),
                f"{row.domain_entropy:.3f}",
                Text.from_markup(markup),
                f"{row.confidence:.2f}" if row.label != "pending" else "—",
            )
        return tbl

    def _build_layout(self) -> Layout:
        layout = Layout()
        layout.split_column(
            Layout(self._build_header(), name="header", size=5),
            Layout(self._build_table(), name="body"),
        )
        return layout

    def _live_loop(self) -> None:
        with Live(
            self._build_layout(),
            console=self._console,
            refresh_per_second=int(1 / self._refresh_s),
            screen=False,
        ) as live:
            while self._running:
                live.update(self._build_layout())
                time.sleep(self._refresh_s)
