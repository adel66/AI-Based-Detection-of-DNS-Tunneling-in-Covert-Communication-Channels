"""
worker/consumer.py
------------------
Kafka consumer service.

Continuously polls the ``dns_windows`` topic, classifies each window's
feature vector, and writes the result to Redis so the CLI can retrieve it.

Design decisions
----------------
- Manual offset commit (``enable_auto_commit=False``) after each successful
  batch — guarantees at-least-once processing.
- Thread pool for inference — Kafka poll stays fast; slow models don't stall
  the consumer heartbeat, avoiding partition rebalance.
- Exponential backoff retry on Kafka connection errors.
- Graceful shutdown on SIGINT / SIGTERM.
"""

from __future__ import annotations

import json
import logging
import signal
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

from kafka import KafkaConsumer
from kafka.errors import KafkaError, NoBrokersAvailable

from api.cache import SyncResultStore
from model.classifier import BaseClassifier, load_classifier
from shared.config import kafka as kafka_cfg, worker as worker_cfg
from shared.logging_setup import configure_logging

configure_logging("worker")
logger = logging.getLogger(__name__)


# ── Kafka connection with retry ───────────────────────────────────────────────

def _connect_consumer(retries: int = 12, base_delay: float = 3.0) -> KafkaConsumer:
    """
    Attempt to connect with exponential backoff.
    Exits the process if all retries are exhausted.
    """
    delay = base_delay
    for attempt in range(1, retries + 1):
        try:
            consumer = KafkaConsumer(
                kafka_cfg.topic,
                bootstrap_servers=kafka_cfg.bootstrap_servers,
                group_id=kafka_cfg.consumer_group,
                value_deserializer=lambda b: json.loads(b.decode("utf-8")),
                auto_offset_reset="earliest",
                enable_auto_commit=False,
                max_poll_records=worker_cfg.max_poll_records,
                session_timeout_ms=45_000,
                heartbeat_interval_ms=10_000,
                fetch_min_bytes=1,
                fetch_max_wait_ms=worker_cfg.poll_timeout_ms,
            )
            logger.info("Connected to Kafka on attempt %d", attempt)
            return consumer
        except NoBrokersAvailable:
            logger.warning(
                "Kafka not reachable (attempt %d/%d) — retrying in %.0fs",
                attempt, retries, delay,
            )
            time.sleep(delay)
            delay = min(delay * 1.5, 30.0)

    logger.error("Cannot connect to Kafka after %d attempts. Exiting.", retries)
    sys.exit(1)


# ── Per-message processing ────────────────────────────────────────────────────

def _process_message(
    msg:       dict,
    clf:       BaseClassifier,
    store:     SyncResultStore,
) -> tuple[str, str, float]:
    """
    Classify one window message and persist the result.

    Parameters
    ----------
    msg : dict
        Decoded Kafka message value:
        ``{ window_id, agent_id, window_start, window_end, features: {...} }``
    clf : BaseClassifier
    store : SyncResultStore

    Returns
    -------
    window_id, label, confidence
    """
    window_id = msg.get("window_id", "unknown")

    try:
        raw_features: dict = msg.get("features", {})

        # Reconstruct the ordered feature vector
        feature_vector: list[float] = [
            float(raw_features.get("query_count",               0)),
            float(raw_features.get("unique_domain_count",       0)),
            float(raw_features.get("unique_ratio",              0)),
            float(raw_features.get("domain_entropy",            0)),
            float(raw_features.get("mean_per_domain_entropy",   0)),
            float(raw_features.get("high_entropy_domain_ratio", 0)),
            float(raw_features.get("mean_qname_length",         0)),
            float(raw_features.get("std_qname_length",          0)),
            float(raw_features.get("max_qname_length",          0)),
            float(raw_features.get("tld_diversity",             0)),
            float(raw_features.get("suspicious_tld_ratio",      0)),
            float(raw_features.get("mean_digit_ratio",          0)),
            float(raw_features.get("mean_vowel_ratio",          0)),
            float(raw_features.get("inter_query_std",           0)),
        ]

        label, confidence = clf.predict(feature_vector)

        store.set_result(window_id, label, confidence)

        logger.info(
            "Classified window=%s agent=%s label=%s conf=%.3f",
            window_id[:8], msg.get("agent_id", "?"), label, confidence,
        )
        return window_id, label, confidence

    except Exception as exc:
        logger.error("Inference error for window %s: %s", window_id, exc)
        store.set_result(window_id, "unknown", 0.0)
        return window_id, "unknown", 0.0


# ── Worker class ──────────────────────────────────────────────────────────────

class DNSWindowWorker:
    """
    Long-running Kafka consumer + ML inference worker.

    Usage:
        worker = DNSWindowWorker()
        worker.run()        # blocks until Ctrl+C or SIGTERM
    """

    def __init__(self) -> None:
        self._running  = True
        self._clf      = load_classifier()
        self._store    = SyncResultStore()
        self._executor = ThreadPoolExecutor(
            max_workers=worker_cfg.inference_threads,
            thread_name_prefix="inference",
        )
        signal.signal(signal.SIGINT,  self._handle_signal)
        signal.signal(signal.SIGTERM, self._handle_signal)

    def _handle_signal(self, signum, _frame) -> None:
        logger.info("Signal %d received — shutting down gracefully.", signum)
        self._running = False

    def run(self) -> None:
        """Main loop — blocks until stopped."""
        logger.info(
            "DNS Window Worker starting — topic=%s group=%s threads=%d",
            kafka_cfg.topic, kafka_cfg.consumer_group, worker_cfg.inference_threads,
        )

        if not self._store.ping():
            logger.warning("Redis is unreachable — results will not be stored.")

        consumer = _connect_consumer()

        total_processed = 0
        total_errors    = 0
        run_start       = time.time()

        try:
            while self._running:
                poll_result = consumer.poll(
                    timeout_ms=worker_cfg.poll_timeout_ms
                )

                if not poll_result:
                    continue

                # Flatten records from all partitions
                messages: list[dict] = [
                    record.value
                    for records in poll_result.values()
                    for record in records
                    if record.value
                ]

                if not messages:
                    continue

                logger.debug("Polled %d messages", len(messages))

                # Submit all messages to the thread pool concurrently
                futures = {
                    self._executor.submit(_process_message, msg, self._clf, self._store): msg
                    for msg in messages
                }

                for future in as_completed(futures):
                    try:
                        window_id, label, confidence = future.result()
                        total_processed += 1
                    except Exception as exc:
                        logger.error("Unexpected future error: %s", exc)
                        total_errors += 1

                # Commit only after the entire batch is processed
                consumer.commit()

                elapsed = time.time() - run_start
                rate    = total_processed / elapsed if elapsed > 0 else 0.0
                logger.info(
                    "Stats — processed=%d errors=%d rate=%.2f/s",
                    total_processed, total_errors, rate,
                )

        except KafkaError as exc:
            logger.error("Kafka error: %s", exc)
        except Exception as exc:
            logger.exception("Unexpected worker error: %s", exc)
        finally:
            logger.info("Closing consumer and thread pool…")
            consumer.close()
            self._executor.shutdown(wait=True)
            logger.info("Worker stopped.")


# ── Entry point ───────────────────────────────────────────────────────────────

def main() -> None:
    DNSWindowWorker().run()


if __name__ == "__main__":
    main()
