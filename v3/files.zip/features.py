"""
cli/features.py
---------------
Computes the 16-feature statistical vector from a list of ``DomainEvent``
objects captured within one time window.

Every function in this module is pure — it takes data, returns a number,
has no side effects, and is independently testable.

Features (in vector order)
--------------------------
Volume
  0  query_count
  1  unique_domain_count
  2  unique_ratio

Entropy
  3  domain_entropy           — Shannon entropy over all queried domain strings
  4  mean_per_domain_entropy  — average per-domain character entropy
  5  high_entropy_domain_ratio

Length
  6  mean_qname_length
  7  std_qname_length
  8  max_qname_length

TLD
  9  tld_diversity
  10 suspicious_tld_ratio

Character
  11 mean_digit_ratio
  12 mean_vowel_ratio

Timing
  13 inter_query_std
"""

from __future__ import annotations

import math
import statistics
from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Sequence

from cli.parser import DomainEvent


# ── Known-abused TLDs (conservative list) ─────────────────────────────────────

_SUSPICIOUS_TLDS: frozenset[str] = frozenset({
    "xyz", "top", "club", "online", "site", "website",
    "tk",  "ml",  "ga",  "cf",  "gq",  "pw",
    "info", "biz", "cc",  "ws",
})


# ── Low-level math helpers ────────────────────────────────────────────────────

def _shannon_entropy(items: Sequence[str]) -> float:
    """
    Shannon entropy of a sequence of string tokens (treats each token as a symbol).

    H = -Σ p(x) · log2(p(x))

    Returns 0.0 for an empty or single-element sequence.
    """
    if len(items) < 2:
        return 0.0
    total = len(items)
    counts: dict[str, int] = {}
    for item in items:
        counts[item] = counts.get(item, 0) + 1
    return -sum((c / total) * math.log2(c / total) for c in counts.values())


def _char_entropy(s: str) -> float:
    """Shannon entropy over the characters of a single string."""
    return _shannon_entropy(list(s)) if s else 0.0


def _tld(domain: str) -> str:
    """Extract the TLD (rightmost label) from a domain string."""
    parts = domain.rsplit(".", 1)
    return parts[-1] if parts else ""


def _safe_std(values: list[float]) -> float:
    """Population std-dev; returns 0.0 for fewer than 2 values."""
    return statistics.pstdev(values) if len(values) >= 2 else 0.0


def _digit_ratio(domain: str) -> float:
    """Fraction of characters that are digits."""
    if not domain:
        return 0.0
    return sum(c.isdigit() for c in domain) / len(domain)


def _vowel_ratio(domain: str) -> float:
    """
    Fraction of alphabetic characters that are vowels.
    Low vowel ratio is a strong DGA indicator.
    """
    alpha = [c for c in domain.lower() if c.isalpha()]
    if not alpha:
        return 0.0
    return sum(c in "aeiou" for c in alpha) / len(alpha)


# ── Feature dataclass ─────────────────────────────────────────────────────────

@dataclass
class WindowFeatures:
    """
    The complete 16-feature vector for one time window.

    This is the payload sent to the API. Pydantic validation on the server
    side mirrors these field names exactly.
    """

    # Window metadata (not part of the model input vector)
    window_start: datetime
    window_end:   datetime
    agent_id:     str

    # ── Volume ────────────────────────────────────────────────────────
    query_count:          int   = 0
    unique_domain_count:  int   = 0
    unique_ratio:         float = 0.0   # unique / total  (0–1)

    # ── Entropy ───────────────────────────────────────────────────────
    domain_entropy:            float = 0.0  # entropy over full domain strings
    mean_per_domain_entropy:   float = 0.0  # avg per-domain character entropy
    high_entropy_domain_ratio: float = 0.0  # fraction with char-entropy > 3.5

    # ── Length ────────────────────────────────────────────────────────
    mean_qname_length: float = 0.0
    std_qname_length:  float = 0.0
    max_qname_length:  float = 0.0

    # ── TLD ───────────────────────────────────────────────────────────
    tld_diversity:        int   = 0
    suspicious_tld_ratio: float = 0.0  # fraction with suspicious TLD

    # ── Character ─────────────────────────────────────────────────────
    mean_digit_ratio: float = 0.0
    mean_vowel_ratio: float = 0.0

    # ── Timing ────────────────────────────────────────────────────────
    inter_query_std: float = 0.0  # std-dev of inter-arrival times in seconds

    def to_vector(self) -> list[float]:
        """
        Return the 16 numeric features as an ordered list.
        Order must match the training data feature columns.
        """
        return [
            float(self.query_count),
            float(self.unique_domain_count),
            self.unique_ratio,
            self.domain_entropy,
            self.mean_per_domain_entropy,
            self.high_entropy_domain_ratio,
            self.mean_qname_length,
            self.std_qname_length,
            self.max_qname_length,
            float(self.tld_diversity),
            self.suspicious_tld_ratio,
            self.mean_digit_ratio,
            self.mean_vowel_ratio,
            self.inter_query_std,
        ]

    def to_dict(self) -> dict:
        """Serialise to a plain dict (used for JSON payload to API)."""
        d = asdict(self)
        # Convert datetime objects to ISO strings
        d["window_start"] = self.window_start.isoformat()
        d["window_end"]   = self.window_end.isoformat()
        return d


# ── Main computation function ─────────────────────────────────────────────────

def compute_features(
    events:       list[DomainEvent],
    window_start: datetime,
    window_end:   datetime,
    agent_id:     str,
) -> WindowFeatures:
    """
    Compute all 16 features from the domain events in one time window.

    Parameters
    ----------
    events : list[DomainEvent]
        All DNS queries captured during the window (may be empty).
    window_start : datetime
        Start of the aggregation window (clock-aligned).
    window_end : datetime
        End of the aggregation window.
    agent_id : str
        Unique identifier of the CLI instance.

    Returns
    -------
    WindowFeatures
        Fully populated feature object ready to be serialised and sent.
    """
    features = WindowFeatures(
        window_start=window_start,
        window_end=window_end,
        agent_id=agent_id,
    )

    # Empty window — return zero-vector (still worth sending; zeros are signal)
    if not events:
        return features

    domains    = [e.domain for e in events]
    timestamps = [e.timestamp.timestamp() for e in events]

    unique_domains = list(set(domains))

    # ── Volume ────────────────────────────────────────────────────────────────
    features.query_count         = len(domains)
    features.unique_domain_count = len(unique_domains)
    features.unique_ratio        = len(unique_domains) / len(domains)

    # ── Entropy ───────────────────────────────────────────────────────────────
    features.domain_entropy = _shannon_entropy(domains)

    per_domain_entropies = [_char_entropy(d) for d in unique_domains]
    features.mean_per_domain_entropy   = statistics.mean(per_domain_entropies)
    features.high_entropy_domain_ratio = sum(
        1 for e in per_domain_entropies if e > 3.5
    ) / len(unique_domains)

    # ── Length ────────────────────────────────────────────────────────────────
    lengths = [float(len(d)) for d in domains]
    features.mean_qname_length = statistics.mean(lengths)
    features.std_qname_length  = _safe_std(lengths)
    features.max_qname_length  = max(lengths)

    # ── TLD ───────────────────────────────────────────────────────────────────
    tlds = [_tld(d) for d in domains]
    features.tld_diversity        = len(set(tlds))
    features.suspicious_tld_ratio = sum(
        1 for t in tlds if t in _SUSPICIOUS_TLDS
    ) / len(tlds)

    # ── Character ─────────────────────────────────────────────────────────────
    features.mean_digit_ratio = statistics.mean(_digit_ratio(d) for d in domains)
    features.mean_vowel_ratio = statistics.mean(_vowel_ratio(d) for d in domains)

    # ── Timing ────────────────────────────────────────────────────────────────
    if len(timestamps) >= 2:
        sorted_ts = sorted(timestamps)
        gaps = [sorted_ts[i + 1] - sorted_ts[i] for i in range(len(sorted_ts) - 1)]
        features.inter_query_std = _safe_std(gaps)
    # else: stays 0.0 — not enough events to compute gaps

    return features
