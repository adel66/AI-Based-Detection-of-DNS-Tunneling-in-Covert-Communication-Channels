"""
cli/parser.py
-------------
Consumes raw Scapy packets from the sniffer queue, extracts the queried
domain name and the capture timestamp, and pushes ``DomainEvent`` objects
into a second queue for the window aggregator.

Runs in a dedicated daemon thread.
"""

from __future__ import annotations

import logging
import threading
from dataclasses import dataclass
from datetime import datetime
from queue import Empty, Queue

from scapy.all import DNSQR

logger = logging.getLogger(__name__)


# ── Data model ────────────────────────────────────────────────────────────────

@dataclass(slots=True)
class DomainEvent:
    """
    A single captured DNS query, normalised and timestamped.

    Attributes
    ----------
    domain : str
        Lowercase domain without trailing dot.
    timestamp : datetime
        When the packet was captured (local clock).
    """
    domain:    str
    timestamp: datetime


# ── Helpers ───────────────────────────────────────────────────────────────────

def _extract_domain(packet) -> str | None:
    """
    Pull the QNAME from a Scapy packet and normalise it.

    Returns ``None`` if extraction fails or the result is empty.
    """
    try:
        raw = packet[DNSQR].qname
        domain = (raw.decode("utf-8", errors="replace") if isinstance(raw, bytes) else raw)
        domain = domain.rstrip(".").lower().strip()
        return domain if domain else None
    except Exception as exc:
        logger.debug("Domain extraction failed: %s", exc)
        return None


# ── Parser thread ─────────────────────────────────────────────────────────────

class DNSParser:
    """
    Reads raw packets from ``packet_queue``, normalises each domain, and
    writes ``DomainEvent`` objects to ``event_queue``.

    Parameters
    ----------
    packet_queue : Queue
        Source — filled by ``DNSSniffer``.
    event_queue : Queue
        Sink — consumed by the ``WindowAggregator``.
    """

    def __init__(self, packet_queue: Queue, event_queue: Queue) -> None:
        self.packet_queue = packet_queue
        self.event_queue  = event_queue
        self._running     = False

    def start(self) -> None:
        """Spawn the parser thread and return immediately."""
        self._running = True
        thread = threading.Thread(target=self._loop, daemon=True, name="parser")
        thread.start()
        logger.info("Parser started.")

    def stop(self) -> None:
        self._running = False

    def _loop(self) -> None:
        while self._running:
            try:
                packet = self.packet_queue.get(timeout=0.3)
            except Empty:
                continue

            domain = _extract_domain(packet)
            if domain is None:
                continue

            event = DomainEvent(domain=domain, timestamp=datetime.now())
            self.event_queue.put(event)
            logger.debug("Parsed: %s", domain)
