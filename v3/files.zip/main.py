"""
cli/main.py
-----------
Entry point for the DNS Monitor CLI.

Wires together the full capture-aggregate-send pipeline:

  DNSSniffer → DNSParser → WindowAggregator → WindowSender → Dashboard
                                                    ↕
                                             FastAPI Gateway

Usage (requires root):
    sudo python -m cli.main [options]

Press Ctrl+C to stop.
"""

from __future__ import annotations

import argparse
import os
import socket
import sys
import time
from queue import Queue

# ── Path setup so ``shared.*`` and ``cli.*`` resolve correctly ────────────────
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from shared.config import api as api_cfg, cli as cli_cfg
from shared.logging_setup import configure_logging

configure_logging("cli")

import logging
logger = logging.getLogger(__name__)

from cli.sniffer  import DNSSniffer
from cli.parser   import DNSParser
from cli.window   import WindowAggregator
from cli.sender   import WindowSender
from cli.ui       import Dashboard


# ── Helpers ───────────────────────────────────────────────────────────────────

def _check_root() -> None:
    if os.geteuid() != 0:
        print(
            "\n[ERROR] Root privileges required for packet capture.\n"
            "  Run with: sudo python -m cli.main\n",
            file=sys.stderr,
        )
        sys.exit(1)


def _default_agent_id() -> str:
    """Stable identifier based on hostname.  Can be overridden via --agent."""
    return socket.gethostname()


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="dns-monitor",
        description="DNS Monitor v3 — window-based, multi-agent pipeline",
    )
    parser.add_argument(
        "--iface", "-i",
        default=None,
        metavar="INTERFACE",
        help="Network interface to sniff (default: all interfaces)",
    )
    parser.add_argument(
        "--api", "-a",
        default=api_cfg.base_url,
        metavar="URL",
        help=f"FastAPI base URL (default: {api_cfg.base_url})",
    )
    parser.add_argument(
        "--agent",
        default=_default_agent_id(),
        metavar="ID",
        help="Unique agent identifier (default: hostname)",
    )
    parser.add_argument(
        "--window", "-w",
        type=float,
        default=cli_cfg.window_size_s,
        metavar="SECS",
        help=f"Window size in seconds (default: {cli_cfg.window_size_s})",
    )
    parser.add_argument(
        "--refresh",
        type=float,
        default=cli_cfg.ui_refresh_s,
        metavar="SECS",
        help=f"UI refresh rate in seconds (default: {cli_cfg.ui_refresh_s})",
    )
    return parser.parse_args()


# ── Main ──────────────────────────────────────────────────────────────────────

def main() -> None:
    _check_root()
    args = _parse_args()

    logger.info(
        "Starting DNS Monitor — agent=%s iface=%s api=%s",
        args.agent, args.iface or "all", args.api,
    )

    # ── Queues ────────────────────────────────────────────────────────────────
    # Each queue has a generous maxsize to absorb bursts; if a stage falls
    # behind the put() will block rather than silently drop events.
    packet_queue: Queue = Queue(maxsize=5_000)   # raw Scapy packets
    event_queue:  Queue = Queue(maxsize=5_000)   # parsed DomainEvent objects
    window_queue: Queue = Queue(maxsize=500)     # WindowFeatures awaiting send

    # ── Components ────────────────────────────────────────────────────────────
    sniffer = DNSSniffer(packet_queue, iface=args.iface)
    parser  = DNSParser(packet_queue, event_queue)

    aggregator = WindowAggregator(
        event_queue=event_queue,
        window_queue=window_queue,
        agent_id=args.agent,
        window_size_s=args.window,
    )

    dashboard = Dashboard(
        sniffer_ref=sniffer,
        agent_id=args.agent,
        api_url=args.api,
        refresh_s=args.refresh,
    )

    def _on_result(window_id: str, label: str, confidence: float) -> None:
        """Callback from WindowSender — updates the UI row."""
        dashboard.update_result(window_id, label, confidence)

    def _on_window_sent(features, window_id: str) -> None:
        """Called by the sender stub; we hook the aggregator instead (see below)."""
        dashboard.add_window(features, window_id)

    # We need to intercept the window between aggregator and sender so we can
    # register it in the dashboard before the result arrives.  We do this with
    # a thin wrapper queue that also notifies the dashboard.
    class _NotifyingQueue(Queue):
        """Wraps a Queue; calls dashboard.add_window when an item is consumed."""
        def get(self, block=True, timeout=None):
            features = super().get(block=block, timeout=timeout)
            return features

    # The sender calls result_callback, which calls dashboard.update_result.
    sender = WindowSender(
        window_queue=window_queue,
        result_callback=_on_result,
        api_base_url=args.api,
    )

    # Patch sender to also register windows in the dashboard when they are sent.
    # We do this by wrapping _send so the dashboard gets the window_id.
    _original_send = sender._send

    def _patched_send(features):
        window_id = _original_send(features)
        if window_id:
            dashboard.add_window(features, window_id)
        return window_id

    sender._send = _patched_send

    # ── Start pipeline (reverse-teardown order below) ─────────────────────────
    try:
        dashboard.start()
        sniffer.start()
        parser.start()
        aggregator.start()
        sender.start()

        logger.info("All components running.  Press Ctrl+C to stop.")

        # Keep main thread alive
        while True:
            time.sleep(1)

    except KeyboardInterrupt:
        print()  # clear the ^C on the terminal

    finally:
        logger.info("Shutting down…")
        sender.stop()
        aggregator.stop()
        parser.stop()
        sniffer.stop()
        dashboard.stop()
        time.sleep(0.8)  # let threads drain their current item
        dashboard.print_summary()


if __name__ == "__main__":
    main()
