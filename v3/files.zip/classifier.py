"""
model/classifier.py
-------------------
Model loading and classification interface.

The model is loaded ONCE at worker startup using ``load_classifier()``.
All prediction calls go through ``BaseClassifier.predict()``, which returns
a ``(label, confidence)`` tuple so the UI can show a confidence bar.

Loading priority:
  1. A serialised sklearn model at ``MODEL_PATH`` (.pkl).
  2. The built-in ``HeuristicClassifier`` (no file needed, always available).

Labels
------
  "normal"     — traffic looks like typical browsing
  "suspicious" — elevated entropy / unusual TLD / beaconing pattern
  "critical"   — strong DGA or exfiltration signal
"""

from __future__ import annotations

import logging
import os
import pickle
from abc import ABC, abstractmethod

from shared.config import worker as worker_cfg

logger = logging.getLogger(__name__)

# Label index for sklearn models trained with integer targets
_LABEL_MAP: dict[int, str] = {0: "normal", 1: "suspicious", 2: "critical"}


# ── Abstract interface ────────────────────────────────────────────────────────

class BaseClassifier(ABC):
    """All classifiers must implement this minimal interface."""

    @abstractmethod
    def predict(self, feature_vector: list[float]) -> tuple[str, float]:
        """
        Classify one window.

        Parameters
        ----------
        feature_vector : list[float]
            Ordered list of 16 floats produced by ``IngestRequest.to_feature_vector()``.

        Returns
        -------
        label : str
            One of "normal", "suspicious", "critical".
        confidence : float
            Probability of the predicted class (0.0–1.0).
        """
        ...


# ── Heuristic fallback ────────────────────────────────────────────────────────

class HeuristicClassifier(BaseClassifier):
    """
    Rule-based classifier operating directly on the 16-feature vector.

    Feature index reference (matching WindowFeatures.to_vector() order):
      0  query_count              7  std_qname_length
      1  unique_domain_count      8  max_qname_length
      2  unique_ratio             9  tld_diversity
      3  domain_entropy          10  suspicious_tld_ratio
      4  mean_per_domain_entropy 11  mean_digit_ratio
      5  high_entropy_ratio      12  mean_vowel_ratio
      6  mean_qname_length       13  inter_query_std
    """

    def predict(self, fv: list[float]) -> tuple[str, float]:
        (
            query_count, unique_count, unique_ratio,
            domain_entropy, mean_domain_entropy, high_entropy_ratio,
            mean_len, std_len, max_len,
            tld_diversity, suspicious_tld_ratio,
            digit_ratio, vowel_ratio,
            inter_query_std,
        ) = fv

        score = 0.0   # accumulate suspicion score 0–1

        # ── Critical signals (strong DGA / exfiltration evidence) ─────────────

        # Very high per-domain entropy → strong DGA signal
        if mean_domain_entropy > 3.8:
            score += 0.40

        # Most queries to suspicious TLDs
        if suspicious_tld_ratio > 0.6:
            score += 0.30

        # Long domains (> 60 chars avg) → subdomain data exfiltration
        if mean_len > 60:
            score += 0.30

        # ── Suspicious signals (moderate evidence) ─────────────────────────────

        # Many unique domains in one second — possible DGA scan
        if unique_count > 50:
            score += 0.20
        elif unique_count > 20:
            score += 0.10

        # Low unique ratio → repetitive beaconing
        if query_count > 5 and unique_ratio < 0.15:
            score += 0.20

        # High entropy across the window as a whole
        if domain_entropy > 4.5:
            score += 0.15

        # High fraction of high-entropy domains
        if high_entropy_ratio > 0.5:
            score += 0.15

        # Very regular inter-query timing (bots are precise)
        if query_count > 5 and inter_query_std < 0.02:
            score += 0.15

        # High digit ratio (DGA pattern)
        if digit_ratio > 0.35:
            score += 0.15

        # Low vowel ratio (DGA pattern)
        if vowel_ratio < 0.20 and query_count > 5:
            score += 0.10

        # ── Classify by cumulative score ───────────────────────────────────────
        score = min(score, 1.0)

        if score >= 0.55:
            return "critical", score
        if score >= 0.25:
            return "suspicious", score
        return "normal", 1.0 - score


# ── sklearn wrapper ───────────────────────────────────────────────────────────

class SklearnClassifier(BaseClassifier):
    """
    Wraps a pre-trained scikit-learn classifier loaded from a ``.pkl`` file.

    The model must expose:
      - ``.predict(X)``        → integer class label array
      - ``.predict_proba(X)``  → probability matrix  (used for confidence)

    Training label convention:  0 = normal, 1 = suspicious, 2 = critical
    """

    def __init__(self, model_path: str) -> None:
        with open(model_path, "rb") as f:
            self._model = pickle.load(f)
        logger.info("Loaded sklearn model from %s", model_path)

    def predict(self, fv: list[float]) -> tuple[str, float]:
        import numpy as np
        X         = np.array([fv])
        raw_label = int(self._model.predict(X)[0])
        label     = _LABEL_MAP.get(raw_label, "unknown")

        # Confidence from the predicted class probability
        try:
            proba      = self._model.predict_proba(X)[0]
            confidence = float(proba[raw_label])
        except AttributeError:
            confidence = 1.0  # model doesn't support predict_proba

        return label, confidence


# ── Factory ───────────────────────────────────────────────────────────────────

def load_classifier(model_path: str | None = None) -> BaseClassifier:
    """
    Load the best available classifier.

    Tries the sklearn model first; falls back to heuristic if the file
    is missing, corrupt, or incompatible.

    Parameters
    ----------
    model_path : str or None
        Path to a ``.pkl`` file.  Defaults to ``worker_cfg.model_path``.
    """
    path = model_path or worker_cfg.model_path

    if path and os.path.isfile(path):
        try:
            clf = SklearnClassifier(path)
            logger.info("Using sklearn classifier: %s", path)
            return clf
        except Exception as exc:
            logger.warning("Failed to load sklearn model: %s — falling back to heuristic.", exc)

    logger.info("Using HeuristicClassifier (no model file at '%s').", path)
    return HeuristicClassifier()
