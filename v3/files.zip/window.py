"""
cli/window.py
-------------
Clock-aligned 1-second window aggregator.

Every second (on the wall-clock second boundary) the aggregator:
  1. Drains all ``DomainEvent`` objects accumulated in the current bucket.
  2. Computes the 16-feature vector via ``features.compute_features()``.
  3. Pushes the resulting ``WindowFeatures`` object into ``window_queue``
     for the HTTP sender to dispatch.

Clock alignment means windows are at 12:00:01.000, 12:00:02.000, etc.,
regardless of when the process started.  This makes windows from different
CLI agents directly comparable on the server side.
"""

from __future__ import annotations

import logging
import threading
import time
from datetime import datetime, timezone
from queue import Empty, Queue

from cli.features import WindowFeatures, compute_features
from cli.parser import DomainEvent
from shared.config import cli as cli_cfg

logger = logging.getLogger(__name__)


class WindowAggregator:
    """
    Reads ``DomainEvent`` objects from ``event_queue``, batches them into
    fixed 1-second windows, computes features, and emits ``WindowFeatures``
    into ``window_queue``.

    Parameters
    ----------
    event_queue : Queue[DomainEvent]
        Source — filled by ``DNSParser``.
    window_queue : Queue[WindowFeatures]
        Sink — consumed by the HTTP sender.
    agent_id : str
        Stable identifier for this CLI instance (included in every window).
    window_size_s : float
        Aggregation window duration in seconds (default 1.0).
    """

    def __init__(
        self,
        event_queue:  Queue,
        window_queue: Queue,
        agent_id:     str,
        window_size_s: float = cli_cfg.window_size_s,
    ) -> None:
        self.event_queue  = event_queue
        self.window_queue = window_queue
        self.agent_id     = agent_id
        self.window_size  = window_size_s
        self._running     = False

        # Stats exposed to the UI
        self.windows_emitted = 0

    # ── public API ────────────────────────────────────────────────────────────

    def start(self) -> None:
        """Spawn the aggregator thread and return immediately."""
        self._running = True
        thread = threading.Thread(target=self._loop, daemon=True, name="aggregator")
        thread.start()
        logger.info("WindowAggregator started — window=%.1fs agent=%s",
                    self.window_size, self.agent_id)

    def stop(self) -> None:
        self._running = False

    # ── internal ──────────────────────────────────────────────────────────────

    @staticmethod
    def _next_boundary(window_size: float) -> float:
        """
        Return the Unix timestamp of the next clock-aligned window boundary.

        Example: if window_size=1.0 and it is currently 12:00:00.350,
        the next boundary is 12:00:01.000.
        """
        now = time.time()
        return (math.floor(now / window_size) + 1) * window_size

    def _loop(self) -> None:
        """
        Main aggregation loop.

        On each iteration:
          - Sleep until the next window boundary.
          - Drain everything from event_queue that arrived in that window.
          - Compute features and emit.
        """
        import math  # local import keeps module-level namespace clean

        while self._running:
            # Compute when the current window ends
            now          = time.time()
            boundary     = (math.floor(now / self.window_size) + 1) * self.window_size
            window_start = datetime.fromtimestamp(boundary - self.window_size)
            window_end   = datetime.fromtimestamp(boundary)

            # Sleep until the boundary
            sleep_duration = boundary - time.time()
            if sleep_duration > 0:
                time.sleep(sleep_duration)

            # Drain all events that arrived before the boundary
            events: list[DomainEvent] = []
            while True:
                try:
                    event = self.event_queue.get_nowait()
                    # Only include events that belong to this window
                    if event.timestamp.timestamp() < boundary:
                        events.append(event)
                    else:
                        # This event belongs to the next window — put it back
                        self.event_queue.put(event)
                        break
                except Empty:
                    break

            # Compute features even for empty windows (zero-vector is signal)
            features = compute_features(
                events=events,
                window_start=window_start,
                window_end=window_end,
                agent_id=self.agent_id,
            )

            self.window_queue.put(features)
            self.windows_emitted += 1

            logger.debug(
                "Window [%s → %s] — %d events emitted",
                window_start.strftime("%H:%M:%S"),
                window_end.strftime("%H:%M:%S"),
                len(events),
            )
