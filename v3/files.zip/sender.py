"""
cli/sender.py
-------------
Consumes ``WindowFeatures`` from the window queue, POSTs each one to
``POST /ingest``, receives a ``window_id``, then polls ``GET /result/{id}``
until the worker has classified it.

Design
------
- Sending and polling both run in the same daemon thread to keep things simple.
- Polling uses a short sleep loop rather than long-polling to avoid server
  connection exhaustion across many agents.
- On API unavailability, the sender logs and drops the window rather than
  buffering indefinitely (Kafka already provides durability server-side).
"""

from __future__ import annotations

import logging
import threading
import time
from queue import Empty, Queue

import httpx

from cli.features import WindowFeatures
from shared.config import cli as cli_cfg

logger = logging.getLogger(__name__)

# Timeout for the ingest POST — should be fast since API just validates + produces
_POST_TIMEOUT  = 5.0
# Timeout per polling GET
_POLL_TIMEOUT  = 3.0


class WindowSender:
    """
    Sends windows to the API and retrieves classification results.

    Parameters
    ----------
    window_queue : Queue[WindowFeatures]
        Source — filled by ``WindowAggregator``.
    result_callback : callable
        Called with (window_id: str, label: str, confidence: float) when
        a result arrives.  The UI registers this callback.
    api_base_url : str
        Base URL of the FastAPI gateway (e.g. ``"http://localhost:8000"``).
    """

    def __init__(
        self,
        window_queue:    Queue,
        result_callback, # Callable[[str, str, float], None]
        api_base_url:    str,
    ) -> None:
        self.window_queue    = window_queue
        self.result_callback = result_callback
        self._ingest_url     = api_base_url.rstrip("/") + "/ingest"
        self._result_url     = api_base_url.rstrip("/") + "/result"
        self._running        = False
        self._client         = httpx.Client(timeout=_POST_TIMEOUT)

    # ── public API ────────────────────────────────────────────────────────────

    def start(self) -> None:
        self._running = True
        thread = threading.Thread(target=self._loop, daemon=True, name="sender")
        thread.start()
        logger.info("WindowSender started → %s", self._ingest_url)

    def stop(self) -> None:
        self._running = False
        self._client.close()

    # ── internal ──────────────────────────────────────────────────────────────

    def _loop(self) -> None:
        """Drain window_queue; for each window, send then poll."""
        while self._running:
            try:
                features: WindowFeatures = self.window_queue.get(timeout=0.5)
            except Empty:
                continue

            window_id = self._send(features)
            if window_id is None:
                continue  # API unreachable — window dropped; logged in _send

            # Poll for the result in a dedicated thread so we can immediately
            # pick up the next window from the queue
            poll_thread = threading.Thread(
                target=self._poll_result,
                args=(window_id,),
                daemon=True,
                name=f"poll-{window_id[:8]}",
            )
            poll_thread.start()

    def _send(self, features: WindowFeatures) -> str | None:
        """
        POST the feature vector to /ingest.

        Returns the ``window_id`` assigned by the server, or ``None`` on failure.
        """
        try:
            payload = features.to_dict()
            response = self._client.post(self._ingest_url, json=payload)
            response.raise_for_status()
            data = response.json()
            window_id = data["window_id"]
            logger.debug("Sent window %s (%d events)", window_id, features.query_count)
            return window_id

        except httpx.TimeoutException:
            logger.warning("POST /ingest timed out — window dropped.")
        except httpx.HTTPStatusError as exc:
            logger.error("POST /ingest HTTP %d: %s", exc.response.status_code, exc)
        except Exception as exc:
            logger.error("POST /ingest failed: %s", exc)

        return None

    def _poll_result(self, window_id: str) -> None:
        """
        Poll GET /result/{window_id} until a final label is received or
        the max wait time is exceeded.
        """
        deadline = time.monotonic() + cli_cfg.poll_max_wait_s
        url      = f"{self._result_url}/{window_id}"

        with httpx.Client(timeout=_POLL_TIMEOUT) as client:
            while time.monotonic() < deadline:
                try:
                    response = client.get(url)
                    response.raise_for_status()
                    data  = response.json()
                    label = data.get("label", "pending")

                    if label != "pending":
                        confidence = float(data.get("confidence", 0.0))
                        self.result_callback(window_id, label, confidence)
                        logger.debug("Result for %s: %s (%.2f)", window_id, label, confidence)
                        return

                except httpx.TimeoutException:
                    logger.debug("Poll timeout for %s — retrying", window_id)
                except Exception as exc:
                    logger.warning("Poll error for %s: %s", window_id, exc)

                time.sleep(cli_cfg.poll_interval_s)

        # Timed out — mark as unknown so the UI doesn't hang on pending
        logger.warning("Polling exhausted for window %s — marking unknown.", window_id)
        self.result_callback(window_id, "unknown", 0.0)
